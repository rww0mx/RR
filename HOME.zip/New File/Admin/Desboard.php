<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Professional E-commerce Admin Dashboard</title>
<link href="https://cdn.jsdelivr.net/npm/boxicons@2.1.4/css/boxicons.min.css" rel="stylesheet">
<style>
  *{margin:0;padding:0;box-sizing:border-box;font-family:'Roboto',sans-serif;}
  body{background:#f2f2f2;color:#333;}

  /* --- TOP TOOLBAR --- */
  .toolbar{
    width:100%;
    background:#121212;
    color:#fff;
    padding:15px 20px;
    display:flex;
    justify-content:space-between;
    align-items:center;
    box-shadow:0 3px 6px rgba(0,0,0,0.3);
    position:fixed;
    top:0;
    left:0;
    z-index:100;
    border-radius:0 0 16px 16px;
  }
  .toolbar h1{font-size:20px;}
  .toolbar .user i{font-size:28px;cursor:pointer;}

  /* --- NAVIGATION --- */
  .nav{
    display:flex;
    justify-content:space-around;
    background:#1e1e1e;
    position:fixed;
    bottom:0;
    width:100%;
    padding:10px 0;
    border-radius:16px 16px 0 0;
    box-shadow:0 -3px 6px rgba(0,0,0,0.3);
    z-index:100;
  }
  .nav a{
    color:#fff;
    text-decoration:none;
    display:flex;
    flex-direction:column;
    align-items:center;
    font-size:12px;
    transition:0.2s;
  }
  .nav a i{font-size:24px;margin-bottom:5px;}
  .nav a.active{color:#00e676;}

  /* --- MAIN CONTENT --- */
  .main-content{
    padding:90px 20px 120px 20px;
  }
  .section{display:none;}
  .section.active{display:block;}

  /* --- CARDS --- */
  .cards{
    display:grid;
    grid-template-columns:repeat(auto-fit,minmax(140px,1fr));
    gap:15px;
    margin-bottom:25px;
  }
  .card{
    background:#fff;
    padding:20px;
    border-radius:16px;
    box-shadow:0 4px 8px rgba(0,0,0,0.15);
    display:flex;
    flex-direction:column;
    align-items:center;
  }
  .card h3{font-size:16px;margin-bottom:8px;color:#121212;}
  .card p{font-size:20px;font-weight:bold;margin-bottom:10px;}
  .btn{
    background:#000;
    color:#fff;
    padding:10px 15px;
    border:none;
    border-radius:12px;
    cursor:pointer;
    box-shadow:0 4px 6px rgba(0,0,0,0.3);
    transition:0.2s;
  }
  .btn:hover{background:#222;}

  /* --- TABLE --- */
  table{
    width:100%;
    border-collapse:collapse;
    background:#fff;
    border-radius:12px;
    overflow:hidden;
    box-shadow:0 4px 8px rgba(0,0,0,0.1);
  }
  table th, table td{padding:12px 10px;text-align:left;}
  table th{background:#121212;color:#fff;}
  table tr:nth-child(even){background:#f2f2f2;}

  /* --- FORMS --- */
  .form-group{margin-bottom:15px;}
  .form-group label{display:block;margin-bottom:5px;}
  .form-group input, .form-group textarea, .form-group select{
    width:100%;padding:10px;border-radius:10px;border:1px solid #ccc;
  }

  /* --- RESPONSIVE --- */
  @media(max-width:768px){
    .cards{grid-template-columns:repeat(auto-fit,minmax(120px,1fr));gap:10px;}
  }
</style>
</head>
<body>

  <!-- TOOLBAR -->
  <div class="toolbar">
    <h1>Admin Dashboard</h1>
    <div class="user"><i class='bx bx-user-circle'></i></div>
  </div>

  <!-- MAIN CONTENT -->
  <div class="main-content">

    <!-- DASHBOARD SECTION -->
    <div id="dashboard" class="section active">
      <div class="cards">
        <div class="card">
          <h3>Total Orders</h3>
          <p>1,250</p>
          <button class="btn">View</button>
        </div>
        <div class="card">
          <h3>Total Sales</h3>
          <p>$75,400</p>
          <button class="btn">View</button>
        </div>
        <div class="card">
          <h3>Customers</h3>
          <p>820</p>
          <button class="btn">View</button>
        </div>
        <div class="card">
          <h3>Products</h3>
          <p>320</p>
          <button class="btn">View</button>
        </div>
      </div>

      <h2>Recent Orders</h2>
      <table>
        <thead>
          <tr>
            <th>Order ID</th>
            <th>Customer</th>
            <th>Date</th>
            <th>Status</th>
            <th>Total</th>
          </tr>
        </thead>
        <tbody>
          <tr>
            <td>#1001</td>
            <td>John Doe</td>
            <td>30 Jan 2026</td>
            <td>Completed</td>
            <td>$250</td>
          </tr>
          <tr>
            <td>#1002</td>
            <td>Jane Smith</td>
            <td>29 Jan 2026</td>
            <td>Pending</td>
            <td>$120</td>
          </tr>
          <tr>
            <td>#1003</td>
            <td>Alex Brown</td>
            <td>28 Jan 2026</td>
            <td>Processing</td>
            <td>$340</td>
          </tr>
        </tbody>
      </table>
    </div>

    <!-- ORDERS SECTION -->
    <div id="orders" class="section">
      <h2>Orders</h2>
      <table>
        <thead>
          <tr>
            <th>Order ID</th>
            <th>Customer</th>
            <th>Date</th>
            <th>Status</th>
            <th>Total</th>
          </tr>
        </thead>
        <tbody>
          <tr><td>#1004</td><td>Sarah Lee</td><td>30 Jan 2026</td><td>Pending</td><td>$200</td></tr>
          <tr><td>#1005</td><td>Mike Johnson</td><td>29 Jan 2026</td><td>Completed</td><td>$450</td></tr>
        </tbody>
      </table>
    </div>

    <!-- PRODUCTS SECTION -->
    <div id="products" class="section">
      <h2>Products</h2>
      <table>
        <thead>
          <tr><th>ID</th><th>Name</th><th>Stock</th><th>Price</th><th>Action</th></tr>
        </thead>
        <tbody>
          <tr><td>1</td><td>Product A</td><td>50</td><td>$25</td><td><button class="btn">Edit</button></td></tr>
          <tr><td>2</td><td>Product B</td><td>30</td><td>$45</td><td><button class="btn">Edit</button></td></tr>
        </tbody>
      </table>
    </div>

    <!-- CUSTOMERS SECTION -->
    <div id="customers" class="section">
      <h2>Customers</h2>
      <table>
        <thead>
          <tr><th>ID</th><th>Name</th><th>Email</th><th>Phone</th><th>Action</th></tr>
        </thead>
        <tbody>
          <tr><td>1</td><td>John Doe</td><td>john@example.com</td><td>1234567890</td><td><button class="btn">Block</button></td></tr>
          <tr><td>2</td><td>Jane Smith</td><td>jane@example.com</td><td>9876543210</td><td><button class="btn">Block</button></td></tr>
        </tbody>
      </table>
    </div>

    <!-- ANALYTICS SECTION -->
    <div id="analytics" class="section">
      <h2>Analytics</h2>
      <p>Graph and charts can be placed here (Sales, Revenue, Customers etc.)</p>
    </div>

  </div>

  <!-- NAVIGATION -->
  <div class="nav">
    <a href="#" class="active" data-section="dashboard"><i class='bx bx-home'></i>Dashboard</a>
    <a href="#" data-section="orders"><i class='bx bx-cart'></i>Orders</a>
    <a href="#" data-section="products"><i class='bx bx-box'></i>Products</a>
    <a href="#" data-section="customers"><i class='bx bx-user'></i>Customers</a>
    <a href="#" data-section="analytics"><i class='bx bx-bar-chart'></i>Analytics</a>
  </div>

<script>
  // Navigation click event
  const navLinks = document.querySelectorAll('.nav a');
  const sections = document.querySelectorAll('.section');

  navLinks.forEach(link => {
    link.addEventListener('click', function(e){
      e.preventDefault();

      // Remove active from all nav
      navLinks.forEach(l => l.classList.remove('active'));
      this.classList.add('active');

      // Hide all sections
      sections.forEach(sec => sec.classList.remove('active'));

      // Show target section
      const section = document.getElementById(this.dataset.section);
      section.classList.add('active');
    });
  });
</script>

</body>
</html>